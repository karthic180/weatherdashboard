import requests
import sqlite3
from datetime import datetime, UTC
import time

DB_NAME = "weather.db"

# -----------------------------
# Weather mapping
# -----------------------------
WEATHER_MAP = {
    0: ("☀️", "Clear sky"),
    1: ("🌤️", "Mainly clear"),
    2: ("⛅", "Partly cloudy"),
    3: ("☁️", "Overcast"),
    45: ("🌫️", "Fog"),
    48: ("🌫️", "Depositing rime fog"),
    51: ("🌦️", "Light drizzle"),
    53: ("🌦️", "Moderate drizzle"),
    55: ("🌧️", "Dense drizzle"),
    56: ("🌧️", "Freezing drizzle"),
    57: ("🌧️", "Freezing drizzle (dense)"),
    61: ("🌦️", "Slight rain"),
    63: ("🌧️", "Rain"),
    65: ("🌧️", "Heavy rain"),
    66: ("🌧️", "Freezing rain"),
    67: ("🌧️", "Freezing rain (heavy)"),
    71: ("🌨️", "Slight snow"),
    73: ("🌨️", "Snow"),
    75: ("❄️", "Heavy snow"),
    77: ("❄️", "Snow grains"),
    80: ("🌦️", "Rain showers"),
    81: ("🌧️", "Rain showers (moderate)"),
    82: ("⛈️", "Violent rain showers"),
    85: ("🌨️", "Snow showers"),
    86: ("❄️", "Heavy snow showers"),
    95: ("⛈️", "Thunderstorm"),
    96: ("⛈️", "Thunderstorm with hail"),
    99: ("⛈️", "Severe thunderstorm with hail")
}

def weather_text(code: int) -> str:
    icon, text = WEATHER_MAP.get(code, ("", "Unknown"))
    return f"{icon} {text}".strip()

def c_to_f(c):
    return round((c * 9/5) + 32, 1)

# -----------------------------
# Cities
# -----------------------------
EUROPEAN_CITIES = sorted([
    "Amsterdam", "Athens", "Belgrade", "Berlin", "Bern", "Bratislava",
    "Brussels", "Budapest", "Copenhagen", "Dublin", "Edinburgh",
    "Frankfurt", "Geneva", "Helsinki", "Istanbul", "Krakow", "Lisbon",
    "Ljubljana", "London", "Luxembourg", "Madrid", "Milan", "Munich",
    "Oslo", "Paris", "Porto", "Prague", "Reykjavik", "Riga", "Rome",
    "Sarajevo", "Sofia", "Stockholm", "Tallinn", "Valletta", "Vienna",
    "Vilnius", "Warsaw", "Zagreb", "Zurich"
])

# -----------------------------
# API helpers
# -----------------------------
def geocode_city(city):
    url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {"name": city, "count": 1}
    try:
        response = requests.get(url, params=params, timeout=10).json()
    except Exception:
        return None, None

    results = response.get("results")
    if not results:
        return None, None

    result = results[0]
    return result["latitude"], result["longitude"]

def fetch_weather(city):
    lat, lon = geocode_city(city)
    if lat is None:
        print(f"⚠ Could not geocode {city}")
        return None

    url = "https://api.open-meteo.com/v1/forecast"
    params = {"latitude": lat, "longitude": lon, "current_weather": True}

    try:
        data = requests.get(url, params=params, timeout=10).json()
    except Exception:
        print(f"⚠ Weather API error for {city}")
        return None

    current = data.get("current_weather")
    if not current:
        print(f"⚠ No weather data for {city}")
        return None

    code = current["weathercode"]
    description = weather_text(code)

    temp_c = current["temperature"]
    temp_f = c_to_f(temp_c)

    return {
        "city": city,
        "temperature_c": temp_c,
        "temperature_f": temp_f,
        "description": description,
        "humidity": None,
        "timestamp": datetime.now(UTC).isoformat()
    }

# -----------------------------
# Database
# -----------------------------
def load_to_db(record):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS weather (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            city TEXT,
            temperature_c REAL,
            temperature_f REAL,
            description TEXT,
            humidity REAL,
            timestamp TEXT
        )
    """)

    cursor.execute("""
        INSERT INTO weather (city, temperature_c, temperature_f, description, humidity, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        record["city"],
        record["temperature_c"],
        record["temperature_f"],
        record["description"],
        record["humidity"],
        record["timestamp"]
    ))

    conn.commit()
    conn.close()

# -----------------------------
# Pipeline
# -----------------------------
def run_pipeline():
    print("🌍 Starting ETL...\n")

    for city in EUROPEAN_CITIES[:10]:
        print(f"➡ Fetching weather for {city}...")
        record = fetch_weather(city)

        if record:
            load_to_db(record)
            print(f"   ✔ Saved: {record['temperature_c']}°C / {record['temperature_f']}°F ({record['description']})")
        else:
            print(f"   ✖ Skipped {city}")

        time.sleep(0.5)

    print("\n✅ ETL complete!")

if __name__ == "__main__":
    run_pipeline()

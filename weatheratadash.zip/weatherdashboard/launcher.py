import subprocess
import sys
import os
import shutil
import sqlite3
import socket
import platform

# ---------------------------------------------------------
# Helper: Check if Docker is installed
# ---------------------------------------------------------
def docker_installed() -> bool:
    return shutil.which("docker") is not None

# ---------------------------------------------------------
# Helper: Check if Docker daemon is running
# ---------------------------------------------------------
def docker_running() -> bool:
    if not docker_installed():
        return False
    try:
        result = subprocess.run(
            ["docker", "info"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return result.returncode == 0
    except Exception:
        return False

# ---------------------------------------------------------
# Helper: Check if a port is free
# ---------------------------------------------------------
def check_port(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) != 0

# ---------------------------------------------------------
# Helper: Check API reachability
# ---------------------------------------------------------
def check_api(url="https://api.open-meteo.com/v1/forecast") -> bool:
    try:
        import requests
        r = requests.get(url, timeout=5)
        return r.status_code == 200
    except Exception:
        return False

# ---------------------------------------------------------
# Helper: Check Python packages
# ---------------------------------------------------------
def check_python_packages():
    required = ["requests", "rapidfuzz", "rich", "streamlit"]
    results = {}
    for pkg in required:
        try:
            __import__(pkg)
            results[pkg] = True
        except ImportError:
            results[pkg] = False
    return results

# ---------------------------------------------------------
# Helper: Check SQLite DB
# ---------------------------------------------------------
def check_sqlite_db():
    if not os.path.exists("weather.db"):
        return False, "Database file not found."

    try:
        conn = sqlite3.connect("weather.db")
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        conn.close()
        return True, f"Tables: {tables}"
    except Exception as e:
        return False, str(e)

# ---------------------------------------------------------
# Full Diagnostics
# ---------------------------------------------------------
def run_diagnostics():
    print("\n=== Full System Diagnostics ===")

    # System info
    print(f"Python executable: {sys.executable}")
    print(f"Python version: {platform.python_version()}")
    print(f"Operating System: {platform.system()} {platform.release()}")
    print(f"Working directory: {os.getcwd()}")

    # Docker
    print(f"Docker installed: {docker_installed()}")
    print(f"Docker daemon running: {docker_running()}")

    # Files
    print(f"Weather DB exists: {os.path.exists('weather.db')}")
    print(f"Dockerfile exists: {os.path.exists('Dockerfile')}")
    print(f"requirements.txt exists: {os.path.exists('requirements.txt')}")

    # SQLite
    db_ok, db_info = check_sqlite_db()
    print(f"SQLite DB OK: {db_ok}")
    print(f"SQLite info: {db_info}")

    # Python packages
    print("\nPython package check:")
    pkg_status = check_python_packages()
    for pkg, ok in pkg_status.items():
        print(f" - {pkg}: {'OK' if ok else 'MISSING'}")

    # Network
    print(f"\nInternet connectivity: {check_api('https://www.google.com')}")
    print(f"Open-Meteo API reachable: {check_api()}")

    # Ports
    print(f"Port 8501 free (Streamlit): {check_port(8501)}")

    print("==============================\n")
    input("Press Enter to return to the menu...")

# ---------------------------------------------------------
# Local runners
# ---------------------------------------------------------
def run_local_terminal():
    subprocess.run(f'"{sys.executable}" terminal_app.py', shell=True)

def run_local_web():
    subprocess.run(f'streamlit run web_app.py', shell=True)

def run_local_etl():
    subprocess.run(f'"{sys.executable}" main.py', shell=True)

# ---------------------------------------------------------
# Docker runners (auto fallback)
# ---------------------------------------------------------
def run_docker_or_local_terminal():
    if docker_installed():
        print("🐳 Docker detected — running inside container...")
        subprocess.run('docker build -t weatherapp .', shell=True)
        subprocess.run('docker run -it weatherapp python terminal_app.py', shell=True)
    else:
        print("⚠️ Docker not found — running locally instead.")
        run_local_terminal()

def run_docker_or_local_web():
    if docker_installed():
        print("🐳 Docker detected — running Streamlit inside container...")
        subprocess.run('docker build -t weatherapp .', shell=True)
        subprocess.run('docker run -p 8501:8501 weatherapp streamlit run web_app.py', shell=True)
    else:
        print("⚠️ Docker not found — running locally instead.")
        run_local_web()

def run_docker_or_local_etl():
    if docker_installed():
        print("🐳 Docker detected — running ETL inside container...")
        subprocess.run('docker build -t weatherapp .', shell=True)
        subprocess.run('docker run weatherapp python main.py', shell=True)
    else:
        print("⚠️ Docker not found — running locally instead.")
        run_local_etl()

# ---------------------------------------------------------
# Reset DB
# ---------------------------------------------------------
def reset_database():
    if os.path.exists("weather.db"):
        os.remove("weather.db")
        print("✔ Database reset.")
    else:
        print("No database found.")

# ---------------------------------------------------------
# Main Menu
# ---------------------------------------------------------
def main():
    while True:
        print("\n=== Weather App Launcher ===")
        print("1. Terminal Viewer")
        print("2. Web UI")
        print("3. Run ETL Now")
        print("4. Diagnostics")
        print("5. Reset Database")
        print("6. Exit")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            run_docker_or_local_terminal()
        elif choice == "2":
            run_docker_or_local_web()
        elif choice == "3":
            run_docker_or_local_etl()
        elif choice == "4":
            run_diagnostics()
        elif choice == "5":
            reset_database()
        elif choice == "6":
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()

import sqlite3
from typing import List, Dict, Optional, Any
import requests

# Optional UI enhancements
try:
    from rich.console import Console
    from rich.table import Table
    from rich import box
    RICH_AVAILABLE = True
    console = Console()
except ImportError:
    RICH_AVAILABLE = False
    console = None

try:
    from rapidfuzz import fuzz
    FUZZY_AVAILABLE = True
except ImportError:
    FUZZY_AVAILABLE = False

DB_NAME = "weather.db"

# -----------------------------
# Weather mapping
# -----------------------------
WEATHER_MAP = {
    0: ("☀️", "Clear sky"),
    1: ("🌤️", "Mainly clear"),
    2: ("⛅", "Partly cloudy"),
    3: ("☁️", "Overcast"),
    45: ("🌫️", "Fog"),
    48: ("🌫️", "Depositing rime fog"),
    51: ("🌦️", "Light drizzle"),
    53: ("🌦️", "Moderate drizzle"),
    55: ("🌧️", "Dense drizzle"),
    56: ("🌧️", "Freezing drizzle"),
    57: ("🌧️", "Freezing drizzle (dense)"),
    61: ("🌦️", "Slight rain"),
    63: ("🌧️", "Rain"),
    65: ("🌧️", "Heavy rain"),
    66: ("🌧️", "Freezing rain"),
    67: ("🌧️", "Freezing rain (heavy)"),
    71: ("🌨️", "Slight snow"),
    73: ("🌨️", "Snow"),
    75: ("❄️", "Heavy snow"),
    77: ("❄️", "Snow grains"),
    80: ("🌦️", "Rain showers"),
    81: ("🌧️", "Rain showers (moderate)"),
    82: ("⛈️", "Violent rain showers"),
    85: ("🌨️", "Snow showers"),
    86: ("❄️", "Heavy snow showers"),
    95: ("⛈️", "Thunderstorm"),
    96: ("⛈️", "Thunderstorm with hail"),
    99: ("⛈️", "Severe thunderstorm with hail")
}

def weather_text(code: int) -> str:
    icon, text = WEATHER_MAP.get(code, ("", "Unknown"))
    return f"{icon} {text}".strip()

def c_to_f(c):
    return round((c * 9/5) + 32, 1)

# -----------------------------
# Database helpers
# -----------------------------
def list_cities() -> List[str]:
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT city FROM weather ORDER BY city ASC")
        return [row[0] for row in cursor.fetchall()]

def get_weather_from_db(city: str) -> Optional[Dict[str, Any]]:
    query = """
        SELECT city, temperature_c, temperature_f, description, humidity, timestamp
        FROM weather
        WHERE city = ?
        ORDER BY id DESC
        LIMIT 1
    """

    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute(query, (city,))
        row = cursor.fetchone()

    if not row:
        return None

    return {
        "city": row[0],
        "temperature_c": f"{row[1]}°C",
        "temperature_f": f"{row[2]}°F",
        "condition": row[3],
        "humidity": row[4],
        "timestamp": row[5]
    }

# -----------------------------
# Live API lookup
# -----------------------------
def geocode_city(city: str) -> Optional[Dict[str, Any]]:
    url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {"name": city, "count": 1}

    try:
        r = requests.get(url, params=params, timeout=10).json()
    except Exception:
        return None

    results = r.get("results")
    if not results:
        return None

    result = results[0]
    return {
        "name": result["name"],
        "lat": result["latitude"],
        "lon": result["longitude"]
    }

def fetch_live_weather(lat: float, lon: float) -> Optional[Dict[str, Any]]:
    url = "https://api.open-meteo.com/v1/forecast"
    params = {"latitude": lat, "longitude": lon, "current_weather": True}

    try:
        r = requests.get(url, params=params, timeout=10).json()
    except Exception:
        return None

    current = r.get("current_weather")
    if not current:
        return None

    code = current["weathercode"]
    description = weather_text(code)

    temp_c = current["temperature"]
    temp_f = c_to_f(temp_c)

    return {
        "temperature_c": f"{temp_c}°C",
        "temperature_f": f"{temp_f}°F",
        "condition": description,
        "windspeed": f"{current['windspeed']} km/h",
        "timestamp": current["time"]
    }

# -----------------------------
# Fuzzy search
# -----------------------------
def fuzzy_match(cities: List[str], query: str) -> List[str]:
    query = query.lower()

    if FUZZY_AVAILABLE:
        scored = [
            (city, fuzz.partial_ratio(query, city.lower()))
            for city in cities
        ]
        scored = [c for c in scored if c[1] >= 60]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [c[0] for c in scored]

    return [c for c in cities if query in c.lower()]

# -----------------------------
# UI
# -----------------------------
def show_weather(city: str, data: Dict[str, Any]):
    if RICH_AVAILABLE:
        table = Table(title=f"Weather for {city}", box=box.ROUNDED)
        table.add_column("Field")
        table.add_column("Value")

        for key, value in data.items():
            table.add_row(key.replace("_", " ").capitalize(), str(value))

        console.print(table)
    else:
        print(f"\n=== Weather for {city} ===")
        for key, value in data.items():
            print(f"{key}: {value}")
        print("==========================\n")

# -----------------------------
# Main
# -----------------------------
def main():
    cities = list_cities()

    search = input("\nSearch ANY city (0 to exit): ").strip()
    if search.lower() in ("0", "exit", "quit", "q"):
        print("Goodbye!")
        return

    # Try DB fuzzy match
    matches = fuzzy_match(cities, search)
    if matches:
        city = matches[0]
        record = get_weather_from_db(city)
        if record:
            show_weather(city, record)
            return

    # Live lookup
    geo = geocode_city(search)
    if not geo:
        print("City not found.")
        return

    live = fetch_live_weather(geo["lat"], geo["lon"])
    if not live:
        print("Could not fetch live weather.")
        return

    show_weather(geo["name"], live)

if __name__ == "__main__":
    main()

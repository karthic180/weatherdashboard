🌦 Weather Dashboard
A cross‑platform weather data pipeline and dashboard built with Python.
It fetches live weather data for European cities, stores it in SQLite, and provides both a terminal interface and a Streamlit web UI for viewing conditions in Celsius and Fahrenheit, complete with icons + text descriptions.

The project includes:

ETL pipeline (Open‑Meteo API → SQLite)

Terminal weather viewer with fuzzy search

Streamlit dashboard

Docker support

Full unittest test suite

Makefile (Linux/macOS)

Windows automation script (make.bat)

Weather icons + text fallback

Celsius + Fahrenheit support

🚀 Features
🌍 ETL Pipeline
Fetches live weather for 40+ European cities

Stores:

Temperature (°C and °F)

Weather description (icon + text)

Timestamp

SQLite database (weather.db)

🖥 Terminal App
Fuzzy search for any city

Falls back to live lookup if not in DB

Rich‑formatted output (if rich installed)

🌐 Streamlit Web Dashboard
View stored weather

Live city lookup

Displays:

Temperature (°C / °F)

Icons + text conditions

Humidity

Wind speed

Timestamp

🧪 Testing
Full unittest suite

Windows‑safe SQLite handling

Tests for:

Weather mapping

Temperature conversion

ETL DB writes

Terminal fuzzy search

Web DB helpers

🐳 Docker Support
Build and run ETL, terminal, or web UI inside Docker

⚙ Automation
Makefile (Linux/macOS)

make.bat (Windows)

📦 Installation
1. Clone the repo
bash
git clone https://github.com/yourusername/weatherdashboard.git
cd weatherdashboard
2. Install dependencies
bash
pip install -r requirements.txt
🧰 Commands
Linux/macOS (Makefile)
bash
make etl
make terminal
make web
make test
make reset-db
make docker-build
make docker-web
Windows (make.bat)
cmd
make etl
make terminal
make web
make test
make reset-db
make docker-build
make docker-web
🐳 Docker
Build the image
bash
docker build -t weatherapp .
Run ETL
bash
docker run weatherapp python main.py
Run Terminal App
bash
docker run -it weatherapp python terminal_app.py
Run Web UI
bash
docker run -p 8501:8501 weatherapp streamlit run web_app.py
🧪 Running Tests (unittest)
Discover and run all tests
bash
python -m unittest discover -v
Or explicitly:
bash
python -m unittest discover -s tests -p "test_*.py" -v
📁 Project Structure
Code
weatherdashboard/
│
├── main.py                 # ETL pipeline
├── terminal_app.py         # Terminal weather viewer
├── web_app.py              # Streamlit dashboard
├── launcher.py             # Unified launcher
├── Dockerfile
├── requirements.txt
├── Makefile                # Linux/macOS automation
├── make.bat                # Windows automation
├── .gitignore
│
└── tests/                  # unittest suite
    ├── __init__.py
    ├── test_weather_mapping.py
    ├── test_temperature_conversion.py
    ├── test_etl.py
    ├── test_terminal_helpers.py
    └── test_web_helpers.py
🔧 Configuration
Weather Mapping
Each weather code maps to:

An emoji icon

A text description

Example:

Code
🌧️ Rain
☀️ Clear sky
⛈️ Thunderstorm
Temperature Conversion
Stored in DB as both °C and °F

Displayed in both terminal and web UI

📝 Requirements
Python 3.10+

Streamlit

Requests

Rich (optional)

RapidFuzz (optional)

Docker (optional)

📜 License
MIT License — free to use, modify, and distribute.
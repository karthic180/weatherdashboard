import unittest
from terminal_app import fuzzy_match

class TestTerminalHelpers(unittest.TestCase):

    def test_fuzzy_match(self):
        cities = ["London", "Lisbon", "Paris"]
        result = fuzzy_match(cities, "lon")
        self.assertEqual(result[0], "London")

if __name__ == "__main__":
    unittest.main()

import unittest
import sqlite3
import tempfile
import os
import time
import gc
from main import load_to_db

class TestETL(unittest.TestCase):

    def test_etl_inserts_record(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "weather.db")

            # Monkeypatch DB_NAME
            import main
            main.DB_NAME = db_path

            record = {
                "city": "TestCity",
                "temperature_c": 10,
                "temperature_f": 50,
                "description": "🌧️ Rain",
                "humidity": None,
                "timestamp": "2024-01-01T00:00:00Z"
            }

            load_to_db(record)

            # Open DB and read
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT city, description FROM weather")
            row = cursor.fetchone()
            conn.close()

            # Force Windows to release file lock
            gc.collect()
            time.sleep(0.05)

            self.assertEqual(row[0], "TestCity")
            self.assertEqual(row[1], "🌧️ Rain")

if __name__ == "__main__":
    unittest.main()

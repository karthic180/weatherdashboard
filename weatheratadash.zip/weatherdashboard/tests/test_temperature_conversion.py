import unittest
from main import c_to_f

class TestTemperatureConversion(unittest.TestCase):

    def test_freezing(self):
        self.assertEqual(c_to_f(0), 32.0)

    def test_boiling(self):
        self.assertEqual(c_to_f(100), 212.0)

    def test_random(self):
        self.assertEqual(c_to_f(25), 77.0)

if __name__ == "__main__":
    unittest.main()

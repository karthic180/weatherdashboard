import pytest

@pytest.fixture
def sample_weather_record():
    return {
        "city": "TestCity",
        "temperature_c": 12,
        "temperature_f": 53.6,
        "description": "🌤️ Mainly clear",
        "humidity": None,
        "timestamp": "2024-01-01T00:00:00Z"
    }

import unittest
from main import weather_text

class TestWeatherMapping(unittest.TestCase):

    def test_known_code(self):
        self.assertEqual(weather_text(63), "🌧️ Rain")

    def test_unknown_code(self):
        self.assertEqual(weather_text(999), "Unknown")

if __name__ == "__main__":
    unittest.main()

import unittest
import sqlite3
import tempfile
import os
import time
import gc

class TestWebHelpers(unittest.TestCase):

    def test_db_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "weather.db")

            # Create DB before importing web_app
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE weather (
                    id INTEGER PRIMARY KEY,
                    city TEXT,
                    temperature_c REAL,
                    temperature_f REAL,
                    description TEXT,
                    humidity REAL,
                    timestamp TEXT
                )
            """)
            cursor.execute("""
                INSERT INTO weather (city, temperature_c, temperature_f, description, humidity, timestamp)
                VALUES ('Berlin', 10, 50, '☁️ Overcast', NULL, '2024-01-01')
            """)
            conn.commit()
            conn.close()

            # Force Windows to release file lock
            gc.collect()
            time.sleep(0.05)

            # Import web_app AFTER DB is created
            import web_app
            web_app.DB_NAME = db_path

            result = web_app.get_weather_from_db("Berlin")
            self.assertEqual(result["condition"], "☁️ Overcast")

            # Cleanup again
            gc.collect()
            time.sleep(0.05)

if __name__ == "__main__":
    unittest.main()

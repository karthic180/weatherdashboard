import sqlite3
from typing import List, Dict, Any, Optional
import streamlit as st
import requests

DB_NAME = "weather.db"

# -----------------------------
# Weather mapping
# -----------------------------
WEATHER_MAP = {
    0: ("☀️", "Clear sky"),
    1: ("🌤️", "Mainly clear"),
    2: ("⛅", "Partly cloudy"),
    3: ("☁️", "Overcast"),
    45: ("🌫️", "Fog"),
    48: ("🌫️", "Depositing rime fog"),
    51: ("🌦️", "Light drizzle"),
    53: ("🌦️", "Moderate drizzle"),
    55: ("🌧️", "Dense drizzle"),
    56: ("🌧️", "Freezing drizzle"),
    57: ("🌧️", "Freezing drizzle (dense)"),
    61: ("🌦️", "Slight rain"),
    63: ("🌧️", "Rain"),
    65: ("🌧️", "Heavy rain"),
    66: ("🌧️", "Freezing rain"),
    67: ("🌧️", "Freezing rain (heavy)"),
    71: ("🌨️", "Slight snow"),
    73: ("🌨️", "Snow"),
    75: ("❄️", "Heavy snow"),
    77: ("❄️", "Snow grains"),
    80: ("🌦️", "Rain showers"),
    81: ("🌧️", "Rain showers (moderate)"),
    82: ("⛈️", "Violent rain showers"),
    85: ("🌨️", "Snow showers"),
    86: ("❄️", "Heavy snow showers"),
    95: ("⛈️", "Thunderstorm"),
    96: ("⛈️", "Thunderstorm with hail"),
    99: ("⛈️", "Severe thunderstorm with hail")
}

def weather_text(code: int) -> str:
    icon, text = WEATHER_MAP.get(code, ("", "Unknown"))
    return f"{icon} {text}".strip()

def c_to_f(c):
    return round((c * 9/5) + 32, 1)

# -----------------------------
# Database
# -----------------------------
def list_cities() -> List[str]:
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT city FROM weather ORDER BY city ASC")
        return [row[0] for row in cursor.fetchall()]

def get_weather_from_db(city: str) -> Optional[Dict[str, Any]]:
    query = """
        SELECT city, temperature_c, temperature_f, description, humidity, timestamp
        FROM weather
        WHERE city = ?
        ORDER BY id DESC
        LIMIT 1
    """

    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute(query, (city,))
        row = cursor.fetchone()

    if not row:
        return None

    return {
        "city": row[0],
        "temperature_c": f"{row[1]}°C",
        "temperature_f": f"{row[2]}°F",
        "condition": row[3],
        "humidity": row[4],
        "timestamp": row[5]
    }

# -----------------------------
# Live API
# -----------------------------
def geocode_city(city: str) -> Optional[Dict[str, Any]]:
    url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {"name": city, "count": 1}

    try:
        r = requests.get(url, params=params, timeout=10).json()
    except Exception:
        return None

    results = r.get("results")
    if not results:
        return None

    result = results[0]
    return {
        "name": result["name"],
        "lat": result["latitude"],
        "lon": result["longitude"]
    }

def fetch_live_weather(lat: float, lon: float) -> Optional[Dict[str, Any]]:
    url = "https://api.open-meteo.com/v1/forecast"
    params = {"latitude": lat, "longitude": lon, "current_weather": True}

    try:
        r = requests.get(url, params=params, timeout=10).json()
    except Exception:
        return None

    current = r.get("current_weather")
    if not current:
        return None

    code = current["weathercode"]
    description = weather_text(code)

    temp_c = current["temperature"]
    temp_f = c_to_f(temp_c)

    return {
        "temperature_c": f"{temp_c}°C",
        "temperature_f": f"{temp_f}°F",
        "condition": description,
        "windspeed": f"{current['windspeed']} km/h",
        "timestamp": current["time"]
    }

# -----------------------------
# Streamlit UI
# -----------------------------
def main():
    st.set_page_config(page_title="Weather Dashboard", page_icon="🌦️")

    st.title("🌦 Weather Dashboard")
    st.write("View stored weather or fetch live weather for any city.")

    cities = list_cities()

    col1, col2 = st.columns(2)

    # DB Weather
    with col1:
        st.subheader("Stored Weather")
        if cities:
            selected_city = st.selectbox("Choose a city:", cities)
            if st.button("Show DB Weather"):
                record = get_weather_from_db(selected_city)
                if record:
                    st.metric("Temperature (°C)", record["temperature_c"])
                    st.metric("Temperature (°F)", record["temperature_f"])
                    st.write("Condition:", record["condition"])
                    st.write("Humidity:", record["humidity"])
                    st.write("Timestamp:", record["timestamp"])
                else:
                    st.error("No record found.")
        else:
            st.info("No cities in database. Run ETL first.")

    # Live Weather
    with col2:
        st.subheader("Live Weather Lookup")
        city_query = st.text_input("Search ANY city:")
        if st.button("Fetch Live Weather"):
            geo = geocode_city(city_query)
            if not geo:
                st.error("City not found.")
            else:
                live = fetch_live_weather(geo["lat"], geo["lon"])
                if not live:
                    st.error("Could not fetch live weather.")
                else:
                    st.metric("Temperature (°C)", live["temperature_c"])
                    st.metric("Temperature (°F)", live["temperature_f"])
                    st.write("Condition:", live["condition"])
                    st.write("Wind speed:", live["windspeed"])
                    st.write("Timestamp:", live["timestamp"])

if __name__ == "__main__":
    main()

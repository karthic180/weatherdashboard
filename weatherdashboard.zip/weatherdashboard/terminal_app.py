import sqlite3

# -----------------------------
# DEPENDENCY CHECKS
# -----------------------------
missing = []

# Try Rich
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich import box
    RICH_AVAILABLE = True
    console = Console()
except ImportError:
    RICH_AVAILABLE = False
    missing.append("rich")

# Try RapidFuzz
try:
    from rapidfuzz import fuzz
    FUZZY_AVAILABLE = True
except ImportError:
    FUZZY_AVAILABLE = False
    missing.append("rapidfuzz")

# Try Requests
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    missing.append("requests")


# -----------------------------
# INFORM USER ABOUT MISSING PACKAGES
# -----------------------------
if missing:
    print("\n⚠️  Some optional packages are not installed:")
    for pkg in missing:
        print(f"   - {pkg}")

    print("\nThese features will be limited:")
    if "rich" in missing:
        print("   • No color UI (plain text mode only)")
    if "rapidfuzz" in missing:
        print("   • No fuzzy search (only simple matching)")
    if "requests" in missing:
        print("   • No live weather lookup (database only)")

    print("\nInstall missing packages with:")
    print("   pip install " + " ".join(missing))
    print()


DB_NAME = "weather.db"


# -----------------------------
# WEATHER ICONS
# -----------------------------
WEATHER_ICONS = {
    0: "☀️ Clear sky",
    1: "🌤️ Mainly clear",
    2: "⛅ Partly cloudy",
    3: "☁️ Overcast",
    45: "🌫️ Fog",
    48: "🌫️ Depositing rime fog",
    51: "🌦️ Light drizzle",
    53: "🌦️ Moderate drizzle",
    55: "🌧️ Dense drizzle",
    56: "🌧️ Freezing drizzle",
    57: "🌧️ Freezing drizzle (dense)",
    61: "🌦️ Slight rain",
    63: "🌧️ Rain",
    65: "🌧️ Heavy rain",
    66: "🌧️ Freezing rain",
    67: "🌧️ Freezing rain (heavy)",
    71: "🌨️ Slight snow",
    73: "🌨️ Snow",
    75: "❄️ Heavy snow",
    77: "❄️ Snow grains",
    80: "🌦️ Rain showers",
    81: "🌧️ Rain showers (moderate)",
    82: "⛈️ Violent rain showers",
    85: "🌨️ Snow showers",
    86: "❄️ Heavy snow showers",
    95: "⛈️ Thunderstorm",
    96: "⛈️ Thunderstorm w/ hail",
    99: "⛈️ Severe thunderstorm w/ hail"
}

def get_weather_icon(code):
    return WEATHER_ICONS.get(code, "❓ Unknown")


# -----------------------------
# DATABASE HELPERS
# -----------------------------
def list_cities():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT city FROM weather ORDER BY city ASC")
    cities = [row[0] for row in cursor.fetchall()]
    conn.close()
    return cities


def get_weather_from_db(city):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT city, temperature, description, humidity, timestamp
        FROM weather
        WHERE city = ?
        ORDER BY id DESC
        LIMIT 1
    """, (city,))
    row = cursor.fetchone()
    conn.close()
    return row


# -----------------------------
# LIVE API SEARCH
# -----------------------------
def geocode_city(city_name):
    if not REQUESTS_AVAILABLE:
        return None

    url = f"https://geocoding-api.open-meteo.com/v1/search?name={city_name}&count=1"
    r = requests.get(url).json()

    if "results" not in r or len(r["results"]) == 0:
        return None

    result = r["results"][0]
    return {
        "name": result["name"],
        "lat": result["latitude"],
        "lon": result["longitude"],
        "country": result.get("country", "")
    }


def fetch_live_weather(lat, lon):
    if not REQUESTS_AVAILABLE:
        return None

    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
    r = requests.get(url).json()

    if "current_weather" not in r:
        return None

    w = r["current_weather"]
    return {
        "temperature": w["temperature"],
        "windspeed": w["windspeed"],
        "weathercode": w["weathercode"],
        "time": w["time"]
    }


# -----------------------------
# FUZZY MATCHING
# -----------------------------
def fuzzy_filter(cities, query):
    if FUZZY_AVAILABLE:
        results = []
        for city in cities:
            score = fuzz.partial_ratio(query.lower(), city.lower())
            if score >= 60:
                results.append((city, score))
        results.sort(key=lambda x: x[1], reverse=True)
        return [city for city, score in results]

    # fallback: simple substring match
    return [c for c in cities if query.lower() in c.lower()]


# -----------------------------
# UI HELPERS
# -----------------------------
def rich_search_prompt():
    return console.input(
        "\n[bold green]Search for ANY city (or type 0 to exit):[/bold green] "
    ).strip()


def plain_search_prompt():
    return input("\nSearch for ANY city (or type 0 to exit): ").strip()


def show_rich_weather(city, data):
    table = Table(title=f"Weather for {city}", box=box.ROUNDED, border_style="green")
    table.add_column("Field", style="bold yellow")
    table.add_column("Value", style="bold white")

    for key, value in data.items():
        table.add_row(key.capitalize(), str(value))

    console.print(table)


def show_plain_weather(city, data):
    print(f"\n=== Weather for {city} ===")
    for key, value in data.items():
        print(f"{key.capitalize()}: {value}")
    print("==========================\n")


# -----------------------------
# MAIN APP
# -----------------------------
def main():
    cities = list_cities()

    # SEARCH BAR
    search = rich_search_prompt() if RICH_AVAILABLE else plain_search_prompt()

    if search.lower() in ["0", "exit", "quit", "q"]:
        console.print("[bold cyan]Goodbye![/bold cyan]") if RICH_AVAILABLE else print("Goodbye!")
        return

    # 1. Fuzzy match against stored cities
    filtered = fuzzy_filter(cities, search)

    if filtered:
        city = filtered[0]  # best match
        record = get_weather_from_db(city)

        if record:
            data = {
                "temperature": f"{record[1]}°C",
                "humidity": record[3],
                "condition": get_weather_icon(record[2]),
                "timestamp": record[4]
            }
            show_rich_weather(city, data) if RICH_AVAILABLE else show_plain_weather(city, data)
            return

    # 2. If not in DB → live API search
    geo = geocode_city(search)
    if not geo:
        msg = f"No city found matching '{search}'."
        console.print(f"[bold red]{msg}[/bold red]") if RICH_AVAILABLE else print(msg)
        return

    live = fetch_live_weather(geo["lat"], geo["lon"])
    if not live:
        msg = "Could not fetch live weather."
        console.print(f"[bold red]{msg}[/bold red]") if RICH_AVAILABLE else print(msg)
        return

    data = {
        "temperature": f"{live['temperature']}°C",
        "windspeed": f"{live['windspeed']} km/h",
        "condition": get_weather_icon(live["weathercode"]),
        "timestamp": live["time"]
    }

    show_rich_weather(geo["name"], data) if RICH_AVAILABLE else show_plain_weather(geo["name"], data)


if __name__ == "__main__":
    main()

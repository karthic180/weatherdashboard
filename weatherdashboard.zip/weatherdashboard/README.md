🌦️ Weather ETL, Terminal UI & Web UI
This project fetches real‑time weather data for major European cities using the Open‑Meteo API, stores it in a SQLite database, and lets the user view the weather in two different interfaces:

A colorized terminal UI with fuzzy search

A web UI built with Streamlit

A launcher script allows the user to choose which interface to run.
If Streamlit is missing, the launcher can automatically install it.

📁 Project Structure
Code
weather-etl/
│
├── main.py              # ETL pipeline (fetch + load)
├── terminal_app.py      # Terminal UI (Rich + fuzzy search + fallback)
├── web_app.py           # Streamlit web UI
├── launcher.py          # Choose terminal or web UI (auto-installs Streamlit)
├── weather.db           # SQLite database (auto-created by ETL)
├── requirements.txt     # Dependencies
└── README.md            # Documentation
⚙️ Installation
Install all required packages:

Code
pip install -r requirements.txt
Optional (for colorized terminal UI):

Code
pip install rich
Optional (for fuzzy search):

Code
pip install rapidfuzz
If Streamlit is not recognized on Windows:

Code
python -m pip install streamlit
🏗️ Step 1 — Run the ETL Pipeline
Before using the viewers, populate the database:

Code
python main.py
This will:

Fetch weather for all supported European cities

Create weather.db if it doesn’t exist

Insert the latest weather records

If ETL password protection is enabled, you will be prompted to enter it.

🚀 Step 2 — Choose Terminal or Web UI
Use the launcher:

Code
python launcher.py
You will see:

Code
=== Weather App Launcher ===
1. Terminal Viewer
2. Web UI
3. Exit
🖥️ Option 1 — Terminal Viewer
Runs a text‑based interface directly in the terminal:

Code
python terminal_app.py
Features
✔ Fuzzy search (e.g., ldn → London, brln → Berlin)

✔ Color UI if Rich is installed

✔ Plain fallback if Rich is missing

✔ Exit option (0, exit, quit, q)

✔ Clean, readable weather output

🌐 Option 2 — Web UI (Streamlit)
Runs the interactive dashboard:

Code
python -m streamlit run web_app.py
Features
✔ Auto‑open browser

✔ Auto‑install Streamlit if missing

✔ Read‑only UI

✔ No deploy button

📝 Notes
Always run the ETL before using the viewers.

Rich and RapidFuzz are optional — the app works perfectly without them.

The launcher provides a simple, user‑friendly interface.
import os
import importlib.util
import subprocess
import sys
import socket

# -----------------------------
# Helper: Check if package installed
# -----------------------------
def is_installed(package_name):
    return importlib.util.find_spec(package_name) is not None

# -----------------------------
# Helper: Install package
# -----------------------------
def install_package(package_name):
    try:
        print(f"\nInstalling {package_name}...\n")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        print(f"\n{package_name} installed successfully!\n")
        return True
    except Exception as e:
        print(f"\nFailed to install {package_name}: {e}")
        return False

# -----------------------------
# Auto-create database if missing
# -----------------------------
def ensure_database():
    if not os.path.exists("weather.db"):
        print("\n⚠️  weather.db not found. Creating it now...\n")
        subprocess.call([sys.executable, "init_db.py"])

# -----------------------------
# Run ETL Now
# -----------------------------
def run_etl():
    ensure_database()

    if not os.path.exists("main.py"):
        print("\n✖ ETL script main.py not found.")
        return

    print("\nRunning ETL pipeline...\n")
    subprocess.call([sys.executable, "main.py"])
    print("\n✔ ETL complete!\n")

# -----------------------------
# Diagnostics
# -----------------------------
def run_diagnostics():
    print("\n=== Diagnostics Report ===")

    # Check DB
    if os.path.exists("weather.db"):
        print("✔ weather.db exists")
    else:
        print("✖ weather.db missing")

    # Check required files
    required_files = [
        "main.py",
        "terminal_app.py",
        "web_app.py",
        "launcher.py",
        "init_db.py"
    ]

    for f in required_files:
        if os.path.exists(f):
            print(f"✔ {f} found")
        else:
            print(f"✖ {f} missing")

    # Check dependencies
    deps = {
        "requests": "Required for live weather",
        "rich": "Optional (color UI)",
        "rapidfuzz": "Optional (fuzzy search)",
        "streamlit": "Optional (web UI)"
    }

    for pkg, desc in deps.items():
        if is_installed(pkg):
            print(f"✔ {pkg} installed ({desc})")
        else:
            print(f"✖ {pkg} NOT installed ({desc})")

    # Check internet connection
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=2)
        print("✔ Internet connection OK")
    except OSError:
        print("✖ No internet connection")

    print("\nDiagnostics complete.\n")

# -----------------------------
# Reset Database
# -----------------------------
def reset_database():
    print("\n⚠️ WARNING: This will DELETE all weather data.")
    choice = input("Are you sure you want to reset the database? (y/n): ").strip().lower()

    if choice != "y":
        print("Database reset cancelled.")
        return

    if os.path.exists("weather.db"):
        os.remove("weather.db")
        print("✔ weather.db deleted")

    print("Recreating database...")
    subprocess.call([sys.executable, "init_db.py"])
    print("✔ Database reset complete!\n")

# -----------------------------
# Run Terminal Viewer
# -----------------------------
def run_terminal():
    ensure_database()
    os.system(f"{sys.executable} terminal_app.py")

# -----------------------------
# Run Web UI
# -----------------------------
def run_web():
    ensure_database()

    if not is_installed("streamlit"):
        print("\n⚠️  Streamlit is not installed.")
        choice = input("Would you like to install it now? (y/n): ").strip().lower()

        if choice != "y":
            print("Returning to launcher...")
            return

        if not install_package("streamlit"):
            print("Could not install Streamlit. Web UI cannot be launched.")
            return

    os.system(f"{sys.executable} -m streamlit run web_app.py --server.headless false")

# -----------------------------
# Main Menu
# -----------------------------
def main():
    while True:
        print("\n=== Weather App Launcher ===")
        print("1. Terminal Viewer")
        print("2. Web UI")
        print("3. Run ETL Now")
        print("4. Diagnostics")
        print("5. Reset Database")
        print("6. Exit")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            run_terminal()
        elif choice == "2":
            run_web()
        elif choice == "3":
            run_etl()
        elif choice == "4":
            run_diagnostics()
        elif choice == "5":
            reset_database()
        elif choice == "6":
            print("Goodbye")
            break
        else:
            print("Invalid choice. Try again.")

# -----------------------------
# Entry Point
# -----------------------------
if __name__ == "__main__":
    main()

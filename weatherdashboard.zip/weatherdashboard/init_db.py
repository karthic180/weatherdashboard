import sqlite3
import os

DB_NAME = "weather.db"

def initialize_database():
    if os.path.exists(DB_NAME):
        print("Database already exists. No action taken.")
        return

    print("Creating new weather.db database...")

    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS weather (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            city TEXT NOT NULL,
            temperature REAL,
            description INTEGER,
            humidity INTEGER,
            timestamp TEXT
        )
    """)

    conn.commit()
    conn.close()

    print("Database created successfully!")

if __name__ == "__main__":
    initialize_database()

import sqlite3
import os

DB_NAME = "weather.db"

def db_exists():
    return os.path.exists(DB_NAME)

def get_weather_for_city(city):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT city, temperature, description, humidity, timestamp
        FROM weather
        WHERE LOWER(city) = LOWER(?)
        ORDER BY id DESC
        LIMIT 1
    """, (city,))

    row = cursor.fetchone()
    conn.close()
    return row

def list_available_cities():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("SELECT DISTINCT city FROM weather ORDER BY city ASC")
    cities = [row[0] for row in cursor.fetchall()]

    conn.close()
    return cities

def main():
    print("=== Weather Lookup Tool ===\n")

    # Check if DB exists
    if not db_exists():
        print("⚠ No database found. Run the ETL pipeline first:")
        print("   python main.py")
        return

    cities = list_available_cities()

    if not cities:
        print("⚠ No weather data found in the database.")
        print("   Run the ETL pipeline first: python main.py")
        return

    print("Available cities:\n")
    for c in cities:
        print(" -", c)

    while True:
        city = input("\nEnter a city name (or type 'exit'): ").strip()

        if city.lower() == "exit":
            print("Goodbye!")
            break

        if city == "":
            print("⚠ Please enter a city name.")
            continue

        if city not in cities and city.capitalize() not in cities:
            print(f"⚠ '{city}' is not in the database.")
            print("   Choose a city from the list above.")
            continue

        record = get_weather_for_city(city)

        if record:
            print("\nLatest Weather:")
            print(f"City: {record[0]}")
            print(f"Temperature: {record[1]}°C")
            print(f"Description: {
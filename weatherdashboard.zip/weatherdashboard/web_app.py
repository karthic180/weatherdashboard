import streamlit as st
import sqlite3
import pandas as pd
import streamlit as st

# Disable Streamlit error details for extra safety
st.set_option("client.showErrorDetails", False)


DB_NAME = "weather.db"

def load_cities():
    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT DISTINCT city FROM weather ORDER BY city ASC", conn)
    conn.close()
    return df["city"].tolist()

def load_weather(city):
    conn = sqlite3.connect(DB_NAME)
    query = """
        SELECT city, temperature, description, humidity, timestamp
        FROM weather
        WHERE city = ?
        ORDER BY id DESC
        LIMIT 1
    """
    df = pd.read_sql_query(query, conn, params=(city,))
    conn.close()
    return df

st.title("🌦️ European Weather Dashboard")

st.write("Select a city to view the latest weather data.")

# Check if DB exists
try:
    cities = load_cities()
except:
    st.error("Database not found. Run the ETL pipeline first using `python main.py`.")
    st.stop()

city = st.selectbox("Choose a city:", cities)

if city:
    df = load_weather(city)

    if df.empty:
        st.warning("No weather data found. Run the ETL pipeline first.")
    else:
        st.subheader(f"Latest Weather for {city}")
        st.write(df)




hide_streamlit_style = """
    <style>
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    .stDeployButton {display: none;}
    </style>
"""
st.markdown(hide_streamlit_style, unsafe_allow_html=True)
